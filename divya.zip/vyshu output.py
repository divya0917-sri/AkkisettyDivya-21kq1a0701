Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:\Users\Dwaraka\AppData\Local\Programs\Python\Python312\vyshu project.py
No.of colleges: 20
Name of the college: ab
List of branches: cse it iot
No.of placements: 500
Pass percentage: 60
Distance: 100
Status: autonomous
Transport: yes
Name of the college: cd
List of branches: csit aiml aids
No.of placements: 600
Pass percentage: 70
Distance: 150
Status: jntuk
Transport: no
Name of the college: ef
List of branches: aids aiml mech
No.of placements: 400
Pass percentage: 60
Distance: 200
Status: autonomous
Transport: no
Name of the college: gh
List of branches: csit iot mech
No.of placements: 600
Pass percentage: 70
Distance: 250
Status: jntuk
Transport: yes
Name of the college: ij
List of branches: aids civil iot
No.of placements: 550
Pass percentage: 69
Distance: 250
Status: jntuk
Transport: no
Name of the college: kl
List of branches: cse it iot
No.of placements: 450
Pass percentage: 70
Distance: 200
Status: autonomous
Transport: no
Name of the college: mn
List of branches: aids aiml iot
No.of placements: 550
Pass percentage: 69
Distance: 250
Status: jntuk
Transport: yes
Name of the college: op
List of branches: civil mech iot
No.of placements: 600
Pass percentage: 59
Distance: 300
Status: autonomous
Transport: yes
Name of the college: qr
List of branches: mech cse it
No.of placements: 600
Pass percentage: 50
Distance: 150
Status: jntuk
Transport: no
Name of the college: st
List of branches: csit iot it
No.of placements: 600
Pass percentage: 70
Distance: 150
Status: jntuk
Transport: yes
Name of the college: uv
List of branches: cse it aids
No.of placements: 470
Pass percentage: 65
Distance: 100
Status: autonomous
Transport: no
Name of the college: wx
List of branches: csit aiml aids
No.of placements: 470
Pass percentage: 55
Distance: 120
Status: jntuk
Transport: no
Name of the college: yz
List of branches: aiml aids civil
No.of placements: 660
Pass percentage: 54
Distance: 120
Status: autonomous
Transport: yes
Name of the college: pace
List of branches: cse it csit
No.of placements: 66
Pass percentage: 77
Distance: 130
Status: jntuk
Transport: yes
Name of the college: qis
List of branches: cse it csit
No.of placements: 670
Pass percentage: 68
Distance: 130
Status: autonomous
Transport: no
Name of the college: rise
List of branches: csit civil mech
No.of placements: 490
Pass percentage: 64
Distance: 130
Status: autonomous
Transport: no
Name of the college: prakasam
List of branches: civil aids aiml
No.of placements: 660
Pass percentage: 62
Distance: 250
Status: jntuk
Transport: yes
Name of the college: zx
List of branches: csit cse iot
No.of placements: 370
Pass percentage: 78
Distance: 350
Status: autonomous
Transport: no
Name of the college: civil 
List of branches: cse it iot
No.of placements: 590
Pass percentage: 79
Distance: 140
Status: jntuk
Transport: no
Name of the college: mech
List of branches: civil csit iot
No.of placements: 500
Pass percentage: 60
Distance: 200
Status: jntuk
Transport: no
college	Branch	Placements	Percentage	Distance	Status	Transport	
{'college': 'ab', 'Branch': ['cse', 'it', 'iot'], 'Placements': 500, 'Percentage': 60.0, 'Distance': 100, 'Status': 'autonomous', 'Transport': 'yes'}
{'college': 'cd', 'Branch': ['csit', 'aiml', 'aids'], 'Placements': 600, 'Percentage': 70.0, 'Distance': 150, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'ef', 'Branch': ['aids', 'aiml', 'mech'], 'Placements': 400, 'Percentage': 60.0, 'Distance': 200, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'gh', 'Branch': ['csit', 'iot', 'mech'], 'Placements': 600, 'Percentage': 70.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'ij', 'Branch': ['aids', 'civil', 'iot'], 'Placements': 550, 'Percentage': 69.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'kl', 'Branch': ['cse', 'it', 'iot'], 'Placements': 450, 'Percentage': 70.0, 'Distance': 200, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'mn', 'Branch': ['aids', 'aiml', 'iot'], 'Placements': 550, 'Percentage': 69.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'op', 'Branch': ['civil', 'mech', 'iot'], 'Placements': 600, 'Percentage': 59.0, 'Distance': 300, 'Status': 'autonomous', 'Transport': 'yes'}
{'college': 'qr', 'Branch': ['mech', 'cse', 'it'], 'Placements': 600, 'Percentage': 50.0, 'Distance': 150, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'st', 'Branch': ['csit', 'iot', 'it'], 'Placements': 600, 'Percentage': 70.0, 'Distance': 150, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'uv', 'Branch': ['cse', 'it', 'aids'], 'Placements': 470, 'Percentage': 65.0, 'Distance': 100, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'wx', 'Branch': ['csit', 'aiml', 'aids'], 'Placements': 470, 'Percentage': 55.0, 'Distance': 120, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'yz', 'Branch': ['aiml', 'aids', 'civil'], 'Placements': 660, 'Percentage': 54.0, 'Distance': 120, 'Status': 'autonomous', 'Transport': 'yes'}
{'college': 'pace', 'Branch': ['cse', 'it', 'csit'], 'Placements': 66, 'Percentage': 77.0, 'Distance': 130, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'qis', 'Branch': ['cse', 'it', 'csit'], 'Placements': 670, 'Percentage': 68.0, 'Distance': 130, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'rise', 'Branch': ['csit', 'civil', 'mech'], 'Placements': 490, 'Percentage': 64.0, 'Distance': 130, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'prakasam', 'Branch': ['civil', 'aids', 'aiml'], 'Placements': 660, 'Percentage': 62.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'zx', 'Branch': ['csit', 'cse', 'iot'], 'Placements': 370, 'Percentage': 78.0, 'Distance': 350, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'civil ', 'Branch': ['cse', 'it', 'iot'], 'Placements': 590, 'Percentage': 79.0, 'Distance': 140, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'mech', 'Branch': ['civil', 'csit', 'iot'], 'Placements': 500, 'Percentage': 60.0, 'Distance': 200, 'Status': 'jntuk', 'Transport': 'no'}
     college               Branch  Placements  ...  Distance      Status Transport
0         ab       [cse, it, iot]         500  ...       100  autonomous       yes
1         cd   [csit, aiml, aids]         600  ...       150       jntuk        no
2         ef   [aids, aiml, mech]         400  ...       200  autonomous        no
3         gh    [csit, iot, mech]         600  ...       250       jntuk       yes
4         ij   [aids, civil, iot]         550  ...       250       jntuk        no
5         kl       [cse, it, iot]         450  ...       200  autonomous        no
6         mn    [aids, aiml, iot]         550  ...       250       jntuk       yes
7         op   [civil, mech, iot]         600  ...       300  autonomous       yes
8         qr      [mech, cse, it]         600  ...       150       jntuk        no
9         st      [csit, iot, it]         600  ...       150       jntuk       yes
10        uv      [cse, it, aids]         470  ...       100  autonomous        no
11        wx   [csit, aiml, aids]         470  ...       120       jntuk        no
12        yz  [aiml, aids, civil]         660  ...       120  autonomous       yes
13      pace      [cse, it, csit]          66  ...       130       jntuk       yes
14       qis      [cse, it, csit]         670  ...       130  autonomous        no
15      rise  [csit, civil, mech]         490  ...       130  autonomous        no
16  prakasam  [civil, aids, aiml]         660  ...       250       jntuk       yes
17        zx     [csit, cse, iot]         370  ...       350  autonomous        no
18    civil        [cse, it, iot]         590  ...       140       jntuk        no
19      mech   [civil, csit, iot]         500  ...       200       jntuk        no

[20 rows x 7 columns]
wx
Details of college: 
wx ['csit', 'aiml', 'aids'] 470 55.0 120 jntuk no
Placements greater than 500:  cd
Placements greater than 500:  gh
Placements greater than 500:  ij
Placements greater than 500:  mn
Placements greater than 500:  op
Placements greater than 500:  qr
Placements greater than 500:  st
Placements greater than 500:  yz
Placements greater than 500:  qis
Placements greater than 500:  prakasam
Placements greater than 500:  civil 
kl
Branches:  ['cse', 'it', 'iot']
Transport available college:  ab
Transport available college:  gh
Transport available college:  mn
Transport available college:  op
Transport available college:  st
Transport available college:  yz
Transport available college:  pace
Transport available college:  prakasam
percentage of college:  cd
percentage of college:  gh
percentage of college:  ij
percentage of college:  kl
percentage of college:  mn
percentage of college:  st
percentage of college:  uv
percentage of college:  pace
percentage of college:  qis
percentage of college:  rise
percentage of college:  prakasam
percentage of college:  zx
percentage of college:  civil 
Autonomous college:  ab
Autonomous college:  ef
Autonomous college:  kl
Autonomous college:  op
Autonomous college:  uv
Autonomous college:  yz
Autonomous college:  qis
Autonomous college:  rise
Autonomous college:  zx
count: 9
Max Placements of college:  670 qis
Min Placements of college:  100 ab
Min Placements of college:  100 uv

================================================= RESTART: C:/Users/Dwaraka/Desktop/vr/vyshu project.py =================================================
